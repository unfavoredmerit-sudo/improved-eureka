const menuToggle = document.querySelector('.menu-toggle');
const nav = document.querySelector('nav');
menuToggle.addEventListener('click', () => {
  nav.classList.toggle('active');
});

// Load merch data from merch.json
fetch('merch.json')
  .then(response => response.json())
  .then(data => {
    const productsContainer = document.getElementById('products');
    const featuredContainer = document.getElementById('featuredItems');

    data.merchItems.forEach(item => {
      const productDiv = document.createElement('div');
      productDiv.classList.add('product');
      productDiv.innerHTML = `
        <img src="${item.img}" alt="${item.name}">
        <h3>${item.name}</h3>
        <p>${item.price}</p>
        <a href="${item.link}" target="_blank">Shop Now</a>
      `;
      productsContainer.appendChild(productDiv);
    });

    data.featuredMerch.forEach((item, index) => {
      const featuredDiv = document.createElement('div');
      featuredDiv.classList.add('featured-item');
      if(index === 0) featuredDiv.classList.add('active');
      featuredDiv.innerHTML = `
        <img src="${item.img}" alt="${item.name}">
        <h4>${item.name}</h4>
        <a href="${item.link}" target="_blank">View Item</a>
      `;
      featuredContainer.appendChild(featuredDiv);
    });

    let currentIndex = 0;
    const slides = document.querySelectorAll('.featured-item');
    setInterval(() => {
      slides[currentIndex].classList.remove('active');
      currentIndex = (currentIndex + 1) % slides.length;
      slides[currentIndex].classList.add('active');
    }, 4000);
  });